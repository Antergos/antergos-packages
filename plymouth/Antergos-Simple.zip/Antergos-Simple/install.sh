#! /bin/bash
set -e

# Set tab to 2.
# This script installs the Plymouth theme in the themes sub-directory under Plymouth's
# directory.
#
# 
# Modified version of Grub Theme Install Script Version 2.1 from Towheed Mohammed
# Adapted for use with Plymouth Themes by Dustin Falgout <dustinfalgout@gmail.com> 2013

# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details at <http://www.gnu.org/licenses/>.

# Set properties of theme
# The theme will be installed in a dir with this name.
theme_name='Antergos-Simple'

# Filename of theme definition file.
theme_definition_file='antergos.plymouth'

# Filename of theme script.
theme_script='antergos-script.script'

#Set variables for color.
bold='\E[1m'
red_bold='\E[1;31m'
blue_bold='\E[1;34m'
cyan_bold='\E[1;36m'
green_bold='\E[1;32m'
normal='\E[0m'

msg_yes_no="[${green_bold} y${normal}es ${green_bold}n${normal}o ] "
msg_overwrite_create="[${green_bold} o${normal}verwrite ${green_bold}c${normal}reate ] "

# Directory containing theme files to install.
self=$(dirname $0)

# Default installtion of plymouth.
theme_prefix_default="/usr/share/plymouth"

# Check that the script is being run as root.
if [[ $(id -u) != 0 ]] ; then
	echo -e "${red_bold}Please run this script with root privileges.${normal}"
	exit 0
fi

# Check if Plymouth is installed.
which plymouth > /dev/null
Exit_Code=$?
if [ $(( Exit_Code )) -ge 1 ] ; then
  color 7 4 B
  echo "Plymouth is required but not installed!"
  color 7 0 B
  echo
  echo -n "Would you like to install it? [y/n] (n)? "
  read CHOICE
  if [[ $CHOICE == [Yy] ]] ; then
    sudo pacman -S plymouth
  else
    color 7 4 B
    echo
    echo "Plymouth was not installed!"
    color 7 0 B
    exit 1
  fi
fi

# Create the theme's directory.  If directory already exists, ask the user if
# they would like to overwrite the contents with the new theme or create a new
# theme directory.
theme_dir="${theme_prefix_default}/themes/${theme_name}"
while [[ -d "${theme_dir}" ]] ; do
	echo -e "${blue_bold}Directory ${bold_cyan}${theme_dir}${bold_blue} already exists!${normal}"
	echo -en "Would you like to overwrite it's contents or create a new directory?\
 ${msg_overwrite_create}"
	read response
	case ${response} in
		c|create)
			echo -n "Please enter a new name for the theme's directory: "
			read response
			theme_dir="${theme_prefix_default}/themes/${response}";;
		o|overwrite)
			echo -e "${red_bold}This will delete all files in ${cyan_bold}${theme_dir}${normal}."
			echo -en "Are you sure? ${msg_yes_no}"
			read response
			case ${response} in
				y|yes)
					rm -r "${theme_dir}";;
				*)
					exit 0;;
			esac;;
		*)
			exit 0;;
	esac
done

mkdir -p "${theme_dir}"
echo -e "Installing theme to: ${cyan_bold}${theme_dir}${normal}."

# Copy the theme's files to the theme's directory.
for i in ${self}/* ; do
	cp -r "${i}" "${theme_dir}/$(basename "${i}")"
done


# Ask the user if they would like to set the theme as their new theme.
echo -en "Would you like to set this as your new theme? ${msg_yes_no}"
read response
if [[ ${response} = "yes" || ${response} = "y" ]] ; then
	
	# Set the theme.
	plymouth-set-default-theme antergos -R

fi
exit 0
