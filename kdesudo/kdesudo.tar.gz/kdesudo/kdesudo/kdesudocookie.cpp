/*
 Copyright 2014 Jonathan Riddell <jr@jriddell.org>
 Copyright 1999,2000 Geert Jansen <jansen@kde.org>

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License as
 published by the Free Software Foundation; either version 2 of
 the License or (at your option) version 3 or any later version
 accepted by the membership of KDE e.V. (or its successor approved
 by the membership of KDE e.V.), which shall act as a proxy 
 defined in Section 14 of version 3 of the license.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "kdesudocookie.h"

#include <stdlib.h>

#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtCore/Q_PID>
#include <QDebug>

        class KdeSudoCookie::KdeSudoCookiePrivate
        {
        public:
            QByteArray m_Display;
            QByteArray m_DisplayAuth;
        };

        KdeSudoCookie::KdeSudoCookie()
            : d(new KdeSudoCookiePrivate)
        {
            qDebug() << "KdeSudoCookie::KdeSudoCookie()";
            qDebug() << "#ifdef Q_WS_X11";
            getXCookie();
        }

        KdeSudoCookie::~KdeSudoCookie()
        {
            delete d;
        }

        QByteArray KdeSudoCookie::display() const
        {
            return d->m_Display;
        }

        QByteArray KdeSudoCookie::displayAuth() const
        {
            return d->m_DisplayAuth;
        }

        void KdeSudoCookie::getXCookie()
        {
            d->m_Display = getenv("DISPLAY");
            if (d->m_Display.isEmpty()) {
                qCritical() << "$DISPLAY is not set.";
                return;
            }

            QByteArray disp = d->m_Display;
            if (disp.startsWith("localhost:")) {
                disp.remove(0, 9);
            }

            QProcess proc;
            proc.start("xauth", QStringList() << "list" << disp);
            if (!proc.waitForStarted()) {
                qCritical() << "Could not run xauth.";
                return;
            }
            proc.waitForReadyRead(100);
            QByteArray output = proc.readLine().simplified();
            if (output.isEmpty()) {
                qWarning() << "No X authentication info set for display " << d->m_Display;
                return;
            }
            QList<QByteArray> lst = output.split(' ');
            if (lst.count() != 3) {
                qCritical() << "parse error.";
                return;
            }
            d->m_DisplayAuth = (lst[1] + ' ' + lst[2]);
            proc.waitForFinished(100); // give QProcess a chance to clean up gracefully
        }
