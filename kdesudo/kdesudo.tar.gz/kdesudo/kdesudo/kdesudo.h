/*
 Copyright 2014 Jonathan Riddell <jr@jriddell.org>
 Copyright 2007 Martin Böhm <martin.bohm@kubuntu.org>
 Copyright 2007 Anthony Mercatante <tonio@kubuntu.org>
 Copyright 2007 Canonical Ltd <jriddell@ubuntu.com>
 Copyright 2003 Robert Gruber <rgruber@users.sourceforge.net>

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License as
 published by the Free Software Foundation; either version 2 of
 the License or (at your option) version 3 or any later version
 accepted by the membership of KDE e.V. (or its successor approved
 by the membership of KDE e.V.), which shall act as a proxy 
 defined in Section 14 of version 3 of the license.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef KDESUDO_H
#define KDESUDO_H

// #ifdef HAVE_CONFIG_H FIXME
// #include <config.h>
// #endif

#include "kdesudocookie.h"

#include <QWidget>
#include <QString>
#include <QCommandLineParser>

#include <KProcess>
#include <KPasswordDialog>
#include <KNewPasswordDialog>


/*
 * KdeSudo is the base class of the project
 */
class KdeSudo : QObject
{
    Q_OBJECT
public:
    KdeSudo(const QString &icon, const QString &generic,
            const QCommandLineParser *parser);
    ~KdeSudo();

    enum ResultCodes {
        AsUser = 10
    };

private slots:
    /**
     * This slot gets executed if sudo creates some output
     * -- well, in theory it should. Even though the code
     *  seems to be doing what the API says, it doesn't
     *  yet do what we need.
     **/
    void parseOutput();

    /**
     * This slot gets exectuted when sudo exits
     **/
    void procExited(int exitCode);

    /**
     * This slot overrides the slot from KPasswordDialog
     * @see KPasswordDialog
     **/
    void pushPassword(const QString &);
    void slotCancel();
    void slotUser1();
    QString validArg(QString arg);

private:
    void error(const QString &);
    KProcess *m_process;
    bool m_error;
    bool keepPwd;
    bool emptyPwd;
    bool useTerm;
    bool noExec;
    bool unCleaned;
    QString m_tmpName;
    QString iceauthorityFile;
    KdeSudoCookie *m_pCookie;
    void blockSigChild();
    void unblockSigChild();

    KPasswordDialog *m_dialog;
};

#endif // KDESUDO_H
