/*
 Copyright 2014 Jonathan Riddell <jr@jriddell.org>

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License as
 published by the Free Software Foundation; either version 2 of
 the License or (at your option) version 3 or any later version
 accepted by the membership of KDE e.V. (or its successor approved
 by the membership of KDE e.V.), which shall act as a proxy 
 defined in Section 14 of version 3 of the license.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// Qt headers
#include <QApplication>
#include <QCommandLineParser>
#include <QDebug>

// KDE headers
#include <KAboutData>
#include <KLocalizedString>
#include <KDesktopFile>
#include <KIconLoader>

// application headers
#include "kdesudo.h"

int main(int argc, char **argv)
{
    QApplication application(argc, argv);

    KLocalizedString::setApplicationDomain("kdesudo");
    KAboutData aboutData( QStringLiteral("kdesudo"),
                          i18n("Run command as a different user"),
                          QStringLiteral("0.1"),
                          i18n("Graphical version of sudo, to run a command as a different user"),
                          KAboutLicense::GPL,
                          i18n("(c) 2014, Jonathan Riddell <jr@jriddell.org>"));
    aboutData.addAuthor(i18n("Jonathan Riddell"),i18n("Author"), QStringLiteral("jr@jriddell.org"));

    QCommandLineParser parser;
    parser.addPositionalArgument("command", i18n("The command to execute."));

    QCommandLineOption showProgressOption("p", i18n("Show progress during copy"));
    parser.addOption(showProgressOption);
    QCommandLineOption runAsUserOption("u", i18n("Sets user to run as"), i18n("user"));
    parser.addOption(runAsUserOption);
    QCommandLineOption forgetOption("s", i18n("Forget passwords"));
    parser.addOption(forgetOption);
    QCommandLineOption iconOption("i", i18n("Specify icon to use in the password dialog"), i18n("icon name"));
    parser.addOption(iconOption);
    QCommandLineOption forgetPasswordsOption("s", i18n("Forget passwords"));
    parser.addOption(forgetPasswordsOption);
    QCommandLineOption noShowCommandOption("d", i18n("Do not show the command to be run in the dialog"));
    parser.addOption(noShowCommandOption);
    QCommandLineOption priorityOption("p", i18n("Process priority, between 0 and 100, 0 the lowest [50]"), i18n("priority"));
    parser.addOption(priorityOption);
    QCommandLineOption realtimeOption("r", i18n("Use realtime scheduling"));
    parser.addOption(realtimeOption);
    QCommandLineOption targetUIDOption("f", i18n("Use target UID if <file> is not writeable"), i18n("file"));
    parser.addOption(targetUIDOption);
    QCommandLineOption fakeOption("t", i18n("Fake option for KDE's KdeSu compatibility"));
    parser.addOption(fakeOption);
    QCommandLineOption noKeepPasswordOption("n", i18n("Do not keep password"));
    parser.addOption(noKeepPasswordOption);
    QCommandLineOption noNewDCOPOption("nonewdcop", i18n("Use existing DCOP server FIXME"));
    parser.addOption(noNewDCOPOption);
    QCommandLineOption commentOption("comment", i18n("The comment that should be displayed in the dialog"), i18n("dialog text"));
    parser.addOption(commentOption);
    QCommandLineOption noIgnoreOption("noignorebutton", i18n("Do not display 'ignore' button"));
    parser.addOption(noIgnoreOption);
    QCommandLineOption attachOption("attach", i18n("Makes the dialog transient for an X app specified by winid"), i18n("dialog text"));
    parser.addOption(attachOption);
    QCommandLineOption desktopFileOption("desktop", i18n("Manual override for automatic desktop file detection"), i18n("desktop file"));
    parser.addOption(desktopFileOption);
    
    parser.addHelpOption();
    parser.addVersionOption();
    aboutData.setupCommandLine(&parser);
    parser.process(application);
    aboutData.processCommandLine(&parser);

    QString executable, arg, command, icon;
    QStringList executableList, commandlist;
    KDesktopFile *desktopFile;

    const QStringList args = parser.positionalArguments();
    if (args.count()) {
        command = args[0];
        commandlist = command.split(" ");
        executable = commandlist[0];
    }

    executableList = executable.split("/");
    executable = executableList[executableList.count() - 1];

    // kdesudo4 code for some unknown bug in kubuntu? FIXME
//     KGlobal::dirs()->addResourceDir("apps", "/usr/share/applications/kde");
//     KGlobal::dirs()->addResourceDir("apps", "/usr/share/applications/kde4");
//     KGlobal::dirs()->addResourceDir("apps", "/usr/share/kde/services");
//     KGlobal::dirs()->addResourceDir("apps", "/usr/share/kde4/services");
//     KGlobal::dirs()->addResourceDir("apps", "/usr/share/applications");
//     KGlobal::dirs()->addResourceDir("apps", "/usr/share/applnk");

    QString path = getenv("PATH");
    QStringList pathList = path.split(":");
    for (int i = 0; i < pathList.count(); i++) {
        executable.remove(pathList[i]);
    }
    qDebug() << "KDESUDO executable" << executable;

    if (parser.isSet(desktopFileOption)) {
        desktopFile = new KDesktopFile(parser.value(desktopFileOption));
    } else {
        desktopFile = new KDesktopFile(executable + ".desktop"); //FIXME what does this do? it doesn't find the .desktop file
    }

    if (parser.isSet(iconOption)) {
        icon = parser.value(iconOption);
    } else {
        QString iconName = desktopFile->readIcon();
        KIconLoader *loader = KIconLoader::global();
        icon = loader->iconPath(iconName, -1 * KIconLoader::StdSizes(KIconLoader::SizeHuge),
				true);
    }

    QString name = desktopFile->readName();
    qDebug() << "KDESUDO desktop file name" << name;
    KdeSudo kdesudo(icon, executable, &parser);
    application.setQuitOnLastWindowClosed(false);
    return application.exec();
}
